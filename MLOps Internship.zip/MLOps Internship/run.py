"""
MLOps Batch Job: Rolling Mean Signal Pipeline
Computes a binary trading signal from OHLCV close prices.
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="Rolling-mean signal pipeline")
    parser.add_argument("--input",   required=True, help="Path to input CSV")
    parser.add_argument("--config",  required=True, help="Path to YAML config")
    parser.add_argument("--output",  required=True, help="Path for metrics JSON output")
    parser.add_argument("--log-file", required=True, dest="log_file",
                        help="Path for log file output")
    return parser.parse_args()


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging(log_file: str) -> logging.Logger:
    logger = logging.getLogger("mlops_pipeline")
    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S"
    )

    # File handler – full detail
    fh = logging.FileHandler(log_file, mode="w")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    # Console handler – info+
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


# ---------------------------------------------------------------------------
# Config loading & validation
# ---------------------------------------------------------------------------

REQUIRED_CONFIG_KEYS = {"seed", "window", "version"}


def load_config(config_path: str, logger: logging.Logger) -> dict:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(path, "r") as f:
        cfg = yaml.safe_load(f)

    if not isinstance(cfg, dict):
        raise ValueError("Config YAML must be a mapping (key: value) structure")

    missing = REQUIRED_CONFIG_KEYS - cfg.keys()
    if missing:
        raise ValueError(f"Config missing required keys: {sorted(missing)}")

    if not isinstance(cfg["seed"], int):
        raise ValueError(f"'seed' must be an integer, got: {type(cfg['seed']).__name__}")
    if not isinstance(cfg["window"], int) or cfg["window"] < 1:
        raise ValueError(f"'window' must be a positive integer, got: {cfg['window']}")
    if not isinstance(cfg["version"], str) or not cfg["version"].strip():
        raise ValueError(f"'version' must be a non-empty string, got: {cfg['version']!r}")

    logger.info(
        "Config loaded — version=%s  seed=%d  window=%d",
        cfg["version"], cfg["seed"], cfg["window"]
    )
    return cfg


# ---------------------------------------------------------------------------
# Data loading & validation
# ---------------------------------------------------------------------------

def load_data(input_path: str, logger: logging.Logger) -> pd.DataFrame:
    path = Path(input_path)
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    try:
        df = pd.read_csv(path)
    except Exception as exc:
        raise ValueError(f"Failed to parse CSV: {exc}") from exc

    if df.empty:
        raise ValueError("Input CSV is empty (no rows)")

    if "close" not in df.columns:
        raise ValueError(
            f"Required column 'close' not found. Available columns: {list(df.columns)}"
        )

    # Coerce close to numeric; flag non-parseable values
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    bad_rows = df["close"].isna().sum()
    if bad_rows > 0:
        logger.warning("%d row(s) have non-numeric 'close' values and will be dropped", bad_rows)
        df = df.dropna(subset=["close"]).reset_index(drop=True)

    if df.empty:
        raise ValueError("No valid 'close' values remain after cleaning")

    logger.info("Dataset loaded — %d rows, %d columns: %s",
                len(df), len(df.columns), list(df.columns))
    return df


# ---------------------------------------------------------------------------
# Processing
# ---------------------------------------------------------------------------

def compute_rolling_mean(df: pd.DataFrame, window: int, logger: logging.Logger) -> pd.Series:
    """
    Compute rolling mean of 'close' with the given window.
    The first (window-1) rows will be NaN; those rows are EXCLUDED from signal
    computation (not filled), ensuring no look-ahead bias.
    """
    rolling_mean = df["close"].rolling(window=window, min_periods=window).mean()
    valid = rolling_mean.notna().sum()
    logger.debug(
        "Rolling mean computed — window=%d, valid rows=%d, NaN rows=%d (excluded from signal)",
        window, valid, window - 1
    )
    return rolling_mean


def compute_signal(df: pd.DataFrame, rolling_mean: pd.Series,
                   logger: logging.Logger) -> pd.Series:
    """
    signal = 1 if close > rolling_mean, else 0.
    Rows where rolling_mean is NaN are assigned NaN (excluded from rate calc).
    """
    signal = pd.Series(np.nan, index=df.index)
    valid_mask = rolling_mean.notna()
    signal[valid_mask] = (df.loc[valid_mask, "close"] > rolling_mean[valid_mask]).astype(int)

    valid_count = valid_mask.sum()
    ones = int(signal[valid_mask].sum())
    logger.debug(
        "Signal generated — valid rows=%d, signal=1: %d (%.4f), signal=0: %d (%.4f)",
        valid_count, ones, ones / valid_count,
        valid_count - ones, (valid_count - ones) / valid_count
    )
    return signal


# ---------------------------------------------------------------------------
# Metrics output
# ---------------------------------------------------------------------------

def write_metrics(output_path: str, payload: dict, logger: logging.Logger) -> None:
    with open(output_path, "w") as f:
        json.dump(payload, f, indent=2)
    logger.info("Metrics written to %s", output_path)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args = parse_args()
    logger = setup_logging(args.log_file)

    start_ts = time.perf_counter()
    logger.info("=== Job start ===")
    logger.info(
        "Args — input=%s  config=%s  output=%s  log=%s",
        args.input, args.config, args.output, args.log_file
    )

    version = "unknown"

    try:
        # 1. Load & validate config
        cfg = load_config(args.config, logger)
        version = cfg["version"]
        seed    = cfg["seed"]
        window  = cfg["window"]

        # 2. Set random seed for reproducibility
        np.random.seed(seed)
        logger.info("Random seed set to %d", seed)

        # 3. Load & validate dataset
        df = load_data(args.input, logger)

        # 4. Rolling mean
        logger.info("Computing rolling mean (window=%d)…", window)
        rolling_mean = compute_rolling_mean(df, window, logger)

        # 5. Signal generation
        logger.info("Generating binary signal…")
        signal = compute_signal(df, rolling_mean, logger)

        # 6. Metrics
        valid_mask   = signal.notna()
        rows_processed = int(valid_mask.sum())
        signal_rate  = float(signal[valid_mask].mean())

        latency_ms = round((time.perf_counter() - start_ts) * 1000)

        metrics = {
            "version":        version,
            "rows_processed": rows_processed,
            "metric":         "signal_rate",
            "value":          round(signal_rate, 4),
            "latency_ms":     latency_ms,
            "seed":           seed,
            "status":         "success",
        }

        logger.info(
            "Metrics summary — rows_processed=%d  signal_rate=%.4f  latency_ms=%d",
            rows_processed, signal_rate, latency_ms
        )

        write_metrics(args.output, metrics, logger)
        logger.info("=== Job end — status=success ===")

        # Print final metrics to stdout for Docker capture
        print(json.dumps(metrics, indent=2))
        sys.exit(0)

    except Exception as exc:
        latency_ms = round((time.perf_counter() - start_ts) * 1000)
        logger.error("Pipeline failed: %s", exc, exc_info=True)

        error_metrics = {
            "version":       version,
            "status":        "error",
            "error_message": str(exc),
            "latency_ms":    latency_ms,
        }

        try:
            write_metrics(args.output, error_metrics, logger)
        except Exception as write_exc:
            logger.error("Also failed to write error metrics: %s", write_exc)

        logger.info("=== Job end — status=error ===")
        print(json.dumps(error_metrics, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
