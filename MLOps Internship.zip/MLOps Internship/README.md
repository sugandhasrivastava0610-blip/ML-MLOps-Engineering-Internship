# MLOps Batch Processing Task

## Local Run

python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log

## Docker Build

docker build -t mlops-task .

## Docker Run

docker run --rm mlops-task

## Example Output

See metrics.json
